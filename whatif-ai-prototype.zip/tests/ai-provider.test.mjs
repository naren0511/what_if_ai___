import test from 'node:test';
import assert from 'node:assert/strict';
import {
  checkAICapabilities,
  cleanAndParseJSON,
  interpretNaturalLanguageScenario,
  extractRuleBasedScenarioProposal,
  generateRecoveryStrategies,
  generateRuleBasedRecoveryProposal,
  generateDecisionExplanation,
  generateRuleBasedDecisionExplanation,
  executePromptBattle
} from '../src/engine/aiProvider.ts';
import {
  NLScenarioProposalSchema,
  AIRecoveryProposalSchema,
  AIDecisionExplanationSchema
} from '../src/types/ai.ts';
import { simulate } from '../src/engine/simulation.ts';
import { templates } from '../src/data/templates.ts';

const clone = (obj) => JSON.parse(JSON.stringify(obj));
const getTemplate = (id) => clone(templates.find(t => t.id === id));

// ----------------------------------------------------
// 1. Capability & Environment Safety Tests
// ----------------------------------------------------

test('1. AI Capability check runs safely in any runtime environment without throwing', async () => {
  const caps = await checkAICapabilities();
  assert.ok(typeof caps.webgpuSupported === 'boolean');
  assert.ok(typeof caps.isCompatible === 'boolean');
  assert.ok(Array.isArray(caps.notes));
  assert.ok(caps.recommendedModel.length > 0);
});

// ----------------------------------------------------
// 2. Strict Zod Schema Parsing & Controlled Repair Tests
// ----------------------------------------------------

test('2. cleanAndParseJSON parses pristine JSON conforming to schema', () => {
  const pristine = JSON.stringify({
    interpretation: 'Supplier availability drops by 40%',
    proposedChanges: [
      {
        targetNodeId: 'supplier',
        targetNodeName: 'Primary Supplier',
        variable: 'availability',
        operation: 'multiply',
        value: 0.6,
        reasoning: '40% reduction'
      }
    ],
    confidenceScore: 0.95,
    unresolvedInformation: []
  });

  const res = cleanAndParseJSON(pristine, NLScenarioProposalSchema);
  assert.equal(res.success, true);
  if (res.success) {
    assert.equal(res.data.proposedChanges[0].value, 0.6);
    assert.equal(res.repaired, false);
  }
});

test('3. cleanAndParseJSON repairs markdown code fences and extraneous text', () => {
  const markdownFenced = `Here is the requested analysis:
\`\`\`json
{
  "interpretation": "Demand increases by 20%",
  "proposedChanges": [
    {
      "targetNodeId": "orders",
      "targetNodeName": "Customer Orders",
      "variable": "demand",
      "operation": "multiply",
      "value": 1.2,
      "reasoning": "20% surge"
    }
  ],
  "confidenceScore": 0.9,
  "unresolvedInformation": []
}
\`\`\`
Let me know if you need any adjustments!`;

  const res = cleanAndParseJSON(markdownFenced, NLScenarioProposalSchema);
  assert.equal(res.success, true);
  if (res.success) {
    assert.equal(res.data.proposedChanges[0].targetNodeId, 'orders');
    assert.equal(res.repaired, true);
  }
});

test('4. cleanAndParseJSON repairs trailing commas inside objects and arrays', () => {
  const trailingCommaJSON = `{
    "headline": "Bottleneck detected on Supplier",
    "executiveSummary": "Supplier capacity is degraded.",
    "criticalPathAnalysis": "Causes downstream starvation.",
    "financialAndCostImpact": "Budget overrun of ₹5000.",
    "keyRisks": ["Inventory exhaustion", "Delay propagation",],
    "recommendedNextSteps": ["Buffer capacity", "Demand throttle",],
  }`;

  const res = cleanAndParseJSON(trailingCommaJSON, AIDecisionExplanationSchema);
  assert.equal(res.success, true);
  if (res.success) {
    assert.equal(res.data.keyRisks.length, 2);
    assert.equal(res.repaired, true);
  }
});

test('5. cleanAndParseJSON rejects completely malformed non-JSON with informative error', () => {
  const garbage = 'I am an AI and cannot process this request right now.';
  const res = cleanAndParseJSON(garbage, NLScenarioProposalSchema);
  assert.equal(res.success, false);
  if (!res.success) {
    assert.ok(res.error.includes('No JSON object structure found'));
  }
});

// ----------------------------------------------------
// 3. Natural Language Scenario Interpreter Tests
// ----------------------------------------------------

test('6. NL Scenario Interpreter parses "What if supplier availability falls by 40%?"', async () => {
  const scenario = getTemplate('supply-demo');
  const query = 'What if supplier availability falls by 40%?';
  const { proposal, mode } = await interpretNaturalLanguageScenario(query, scenario);

  assert.ok(['GENERATIVE_AI', 'RULE_BASED'].includes(mode));
  assert.ok(proposal.proposedChanges.length > 0);

  const supChange = proposal.proposedChanges.find(c => c.targetNodeId === 'supplier' || c.targetNodeName.toLowerCase().includes('supplier'));
  assert.ok(supChange, 'Must identify supplier component');
  assert.equal(supChange.variable, 'availability');
  assert.equal(supChange.operation, 'multiply');
  assert.equal(supChange.value, 0.6); // 100% - 40% = 60% = 0.6
});

test('7. NL Scenario Interpreter handles multiple compound changes in query', () => {
  const scenario = getTemplate('business-demo');
  const query = 'What if staff wage increases to 150 and demand increases by 25%?';
  const proposal = extractRuleBasedScenarioProposal(query, scenario);

  assert.ok(proposal.proposedChanges.length > 0);
  assert.ok(proposal.confidenceScore >= 0.7);
  assert.ok(Array.isArray(proposal.unresolvedInformation));
});

// ----------------------------------------------------
// 4. Recovery Strategy Generator Tests
// ----------------------------------------------------

test('8. Recovery Strategy Generator proposes viable interventions citing real bottlenecks', async () => {
  const scenario = getTemplate('campus-demo');
  // Induce bottleneck
  const changes = [
    { id: 'c1', nodeId: 'registration', variable: 'demand', operation: 'set', value: 350, label: 'Demand Surge' }
  ];
  const result = simulate(scenario, changes);

  const { proposal, mode } = await generateRecoveryStrategies(scenario, result);
  assert.ok(['GENERATIVE_AI', 'RULE_BASED'].includes(mode));
  assert.ok(proposal.strategies.length > 0);
  assert.ok(proposal.identifiedRootBottleneck.length > 0);

  const bufferStrat = proposal.strategies.find(s => s.actionType === 'capacity_buffer');
  assert.ok(bufferStrat, 'Should offer capacity buffer strategy');
  assert.ok(bufferStrat.associatedChanges.length > 0);
  assert.equal(bufferStrat.associatedChanges[0].variable, 'capacity');
  assert.ok(bufferStrat.operationalTradeoffs.length > 0);
});

// ----------------------------------------------------
// 5. Decision Explanation Generator Tests
// ----------------------------------------------------

test('9. Decision Explanation Generator synthesizes factual narrative from simulation telemetry', async () => {
  const scenario = getTemplate('supply-demo');
  const changes = [
    { id: 'c1', nodeId: 'supplier', variable: 'availability', operation: 'set', value: 0.5, label: '50% Shortage' }
  ];
  const result = simulate(scenario, changes);

  const { explanation, mode } = await generateDecisionExplanation(scenario, result);
  assert.ok(['GENERATIVE_AI', 'RULE_BASED'].includes(mode));
  assert.ok(explanation.headline.length > 0);
  assert.ok(explanation.executiveSummary.length > 0);
  assert.ok(explanation.criticalPathAnalysis.length > 0);
  assert.ok(explanation.financialAndCostImpact.length > 0);
  assert.ok(explanation.keyRisks.length > 0);
  assert.ok(explanation.recommendedNextSteps.length > 0);

  // Must reference unmet demand if present
  if (result.totalUnmet > 0) {
    assert.ok(explanation.executiveSummary.includes(result.totalUnmet.toFixed(1)) || explanation.criticalPathAnalysis.length > 0);
  }
});

// ----------------------------------------------------
// 6. Prompt Battle Arena Tests
// ----------------------------------------------------

test('10. Prompt Battle executes 3 distinct prompt styles and scores them with deterministic rubrics', async () => {
  const scenario = getTemplate('business-demo');
  const result = simulate(scenario, []);

  const battle = await executePromptBattle(scenario, result);
  assert.ok(['GENERATIVE_AI', 'RULE_BASED'].includes(battle.mode));
  assert.equal(battle.rounds.length, 3);

  const styles = battle.rounds.map(r => r.style);
  assert.ok(styles.includes('zero_shot'));
  assert.ok(styles.includes('role_based'));
  assert.ok(styles.includes('structured_context'));

  for (const round of battle.rounds) {
    assert.ok(round.executionTimeMs > 0);
    assert.ok(round.scores.compositeScore >= 0 && round.scores.compositeScore <= 100);
    assert.ok(round.scores.hallucinationIndex >= 0 && round.scores.hallucinationIndex <= 100);
    assert.ok(round.scores.actionability >= 0 && round.scores.actionability <= 100);
    assert.ok(round.scores.constraintAdherence >= 0 && round.scores.constraintAdherence <= 100);
  }

  assert.ok(['zero_shot', 'role_based', 'structured_context'].includes(battle.winnerStyle));
  assert.ok(battle.rubricSummary.length > 0);
});

// ----------------------------------------------------
// 7. Numerical Integrity Verification
// ----------------------------------------------------

test('11. INVARIANT: AI Provider never recalculates or mutates simulation engine outputs', async () => {
  const scenario = getTemplate('campus-demo');
  const baseline = simulate(scenario, []);
  const initialCost = baseline.totalCost;
  const initialHealth = baseline.overallHealth;
  const initialUnmet = baseline.totalUnmet;

  // Run all AI provider functions
  await interpretNaturalLanguageScenario('What if registration capacity increases by 50?', scenario);
  await generateRecoveryStrategies(scenario, baseline);
  await generateDecisionExplanation(scenario, baseline);
  await executePromptBattle(scenario, baseline);

  // Verify baseline numerical values are strictly untouched
  assert.equal(baseline.totalCost, initialCost);
  assert.equal(baseline.overallHealth, initialHealth);
  assert.equal(baseline.totalUnmet, initialUnmet);
});
