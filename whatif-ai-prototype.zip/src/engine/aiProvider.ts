import { z } from 'zod';
import type { Scenario, ScenarioChange, SimulationResult } from '../types/index.ts';
import {
  type AICapabilities,
  type AIProgress,
  type AIModelId,
  SUPPORTED_LOCAL_MODELS,
  NLScenarioProposalSchema,
  type NLScenarioProposal,
  AIRecoveryProposalSchema,
  type AIRecoveryProposal,
  AIDecisionExplanationSchema,
  type AIDecisionExplanation,
  type PromptBattleResult,
  type PromptBattleRound
} from '../types/ai.ts';
import {
  buildNLScenarioPrompt,
  buildRecoveryStrategyPrompt,
  buildDecisionExplanationPrompt
} from './aiPrompts.ts';
import { formatCurrency } from './simulation.ts';

// Dynamic type for WebLLM engine to avoid forcing static bundle inclusion
let mlcEngine: any = null;
let activeModelId: string | null = null;

// ----------------------------------------------------
// 1. Capability Checking
// ----------------------------------------------------

export async function checkAICapabilities(): Promise<AICapabilities> {
  const notes: string[] = [];

  // Check WebGPU availability in browser
  const hasNavigator = typeof navigator !== 'undefined';
  const hasGPU = hasNavigator && 'gpu' in navigator && (navigator as any).gpu !== undefined;

  if (!hasGPU) {
    notes.push('WebGPU is not enabled or supported in this browser. Running in verified Rule-Based Expert Mode.');
    return {
      webgpuSupported: false,
      hasFP16: false,
      recommendedModel: 'Rule-Based Mode (Deterministic Engine)',
      isCompatible: false,
      notes
    };
  }

  try {
    const gpu = (navigator as any).gpu;
    const adapter = await gpu.requestAdapter();
    if (!adapter) {
      notes.push('WebGPU adapter could not be initialized. Running in Rule-Based Expert Mode.');
      return {
        webgpuSupported: false,
        hasFP16: false,
        recommendedModel: 'Rule-Based Mode',
        isCompatible: false,
        notes
      };
    }

    const hasFP16 = adapter.features ? adapter.features.has('shader-f16') : false;
    const adapterInfo = adapter.info ? {
      vendor: adapter.info.vendor || 'Generic',
      architecture: adapter.info.architecture || 'Unknown',
      description: adapter.info.description || 'GPU Adapter'
    } : undefined;

    notes.push('WebGPU hardware acceleration verified.');
    if (hasFP16) {
      notes.push('Shader FP16 half-precision supported for optimal memory footprint.');
    } else {
      notes.push('Standard 32-bit shader mode supported.');
    }

    return {
      webgpuSupported: true,
      adapterInfo,
      hasFP16,
      recommendedModel: 'SmolLM2-360M-Instruct-q4f16_1-MLC',
      isCompatible: true,
      notes
    };
  } catch (err: any) {
    notes.push(`WebGPU probe failed: ${err.message}. Using Rule-Based Mode.`);
    return {
      webgpuSupported: false,
      hasFP16: false,
      recommendedModel: 'Rule-Based Mode',
      isCompatible: false,
      notes
    };
  }
}

// ----------------------------------------------------
// 2. Model Initialization & Lifecycle
// ----------------------------------------------------

export async function initializeLocalAI(
  modelId: AIModelId = 'SmolLM2-360M-Instruct-q4f16_1-MLC',
  onProgress?: (progress: AIProgress) => void
): Promise<boolean> {
  if (mlcEngine && activeModelId === modelId) {
    if (onProgress) {
      onProgress({ status: 'ready', text: 'Model is active and ready in memory.', progress: 1.0 });
    }
    return true;
  }

  if (onProgress) {
    onProgress({
      status: 'checking',
      text: 'Verifying browser WebGPU and shader capabilities...',
      progress: 0.05
    });
  }

  const caps = await checkAICapabilities();
  if (!caps.webgpuSupported) {
    if (onProgress) {
      onProgress({
        status: 'error',
        text: 'WebGPU is not supported on this browser/device. System will operate in Rule-Based Mode.',
        progress: 0
      });
    }
    return false;
  }

  try {
    if (onProgress) {
      onProgress({
        status: 'downloading',
        text: `Loading WebLLM runtime for ${modelId}...`,
        progress: 0.15
      });
    }

    // Dynamically import WebLLM so initial bundle size stays light
    const webllm = await import('@mlc-ai/web-llm');

    const initProgressCallback = (report: any) => {
      const p = Math.min(1.0, Math.max(0.15, report.progress ?? 0.5));
      if (onProgress) {
        onProgress({
          status: 'loading',
          text: report.text || 'Compiling GPU shaders and caching model weights...',
          progress: p
        });
      }
    };

    mlcEngine = await webllm.CreateMLCEngine(modelId, {
      initProgressCallback
    });

    activeModelId = modelId;

    if (onProgress) {
      onProgress({
        status: 'ready',
        text: `Local model ${modelId} is active in browser memory via WebGPU.`,
        progress: 1.0
      });
    }
    return true;
  } catch (err: any) {
    console.warn('Local WebLLM initialization error:', err);
    mlcEngine = null;
    activeModelId = null;
    if (onProgress) {
      onProgress({
        status: 'error',
        text: `Model initialization failed (${err.message || 'GPU memory allocation error'}). Falling back to Rule-Based Mode.`,
        progress: 0
      });
    }
    return false;
  }
}

export function isLocalAIReady(): boolean {
  return mlcEngine !== null;
}

export function getActiveModelId(): string | null {
  return activeModelId;
}

export async function unloadLocalAI(): Promise<void> {
  if (mlcEngine) {
    try {
      await mlcEngine.unload();
    } catch {
      // ignore cleanup errors
    }
    mlcEngine = null;
    activeModelId = null;
  }
}

// ----------------------------------------------------
// 3. Robust JSON Parsing & Schema Auto-Repair
// ----------------------------------------------------

export function cleanAndParseJSON<T>(rawText: string, schema: z.ZodSchema<T>): { success: true; data: T; repaired: boolean } | { success: false; error: string; raw: string } {
  let cleaned = rawText.trim();
  let wasRepaired = false;

  // Strip markdown code fences if model wrapped in ```json ... ```
  if (cleaned.includes('```')) {
    const match = cleaned.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
    if (match) {
      cleaned = match[1].trim();
      wasRepaired = true;
    }
  }

  // Attempt direct JSON parse
  let parsedObj: any = null;
  try {
    parsedObj = JSON.parse(cleaned);
  } catch {
    // Attempt repair: find outermost curly braces
    const firstBrace = cleaned.indexOf('{');
    const lastBrace = cleaned.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
      const extracted = cleaned.substring(firstBrace, lastBrace + 1);
      // Remove trailing commas before closing braces/brackets
      const fixedCommas = extracted.replace(/,\s*([}\]])/g, '$1');
      try {
        parsedObj = JSON.parse(fixedCommas);
        wasRepaired = true;
      } catch (err2: any) {
        return {
          success: false,
          error: `JSON parse failed after repair attempt: ${err2.message}`,
          raw: rawText
        };
      }
    } else {
      return {
        success: false,
        error: 'No JSON object structure found in model output.',
        raw: rawText
      };
    }
  }

  // Validate parsed structure with Zod schema
  const validation = schema.safeParse(parsedObj);
  if (validation.success) {
    return { success: true, data: validation.data, repaired: wasRepaired || cleaned !== rawText };
  }

  return {
    success: false,
    error: `Schema validation failed: ${validation.error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join(', ')}`,
    raw: rawText
  };
}

// ----------------------------------------------------
// 4. Feature A: Natural Language Scenario Interpreter
// ----------------------------------------------------

export async function interpretNaturalLanguageScenario(
  userInput: string,
  scenario: Scenario
): Promise<{ proposal: NLScenarioProposal; mode: 'GENERATIVE_AI' | 'RULE_BASED' }> {
  // If Local AI is active, run generative inference
  if (mlcEngine) {
    try {
      const prompt = buildNLScenarioPrompt(userInput, scenario);
      const completion = await mlcEngine.chat.completions.create({
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.1,
        max_tokens: 600
      });

      const raw = completion.choices[0]?.message?.content || '';
      const parsed = cleanAndParseJSON(raw, NLScenarioProposalSchema);
      if (parsed.success) {
        return { proposal: parsed.data, mode: 'GENERATIVE_AI' };
      }
      console.warn('AI output failed schema validation. Falling back to deterministic parser:', parsed.error);
    } catch (err) {
      console.warn('Inference error in NL interpreter:', err);
    }
  }

  // Fallback: Deterministic Rule-Based Natural Language Extractor
  return {
    proposal: extractRuleBasedScenarioProposal(userInput, scenario),
    mode: 'RULE_BASED'
  };
}

export function extractRuleBasedScenarioProposal(userInput: string, scenario: Scenario): NLScenarioProposal {
  const lower = userInput.toLowerCase();
  const proposedChanges: any[] = [];
  const unresolved: string[] = [];

  // Match target components by name or ID
  const matchedNodes = scenario.nodes.filter(n => 
    lower.includes(n.id.toLowerCase()) || lower.includes(n.name.toLowerCase())
  );

  // If no node explicitly mentioned, check for domain roles
  const targetNodes = matchedNodes.length > 0 ? matchedNodes : (
    lower.includes('supplier') ? scenario.nodes.filter(n => n.type === 'supplier' || n.name.toLowerCase().includes('supplier')) :
    lower.includes('staff') || lower.includes('volunteer') ? scenario.nodes.filter(n => n.type === 'people' || n.name.toLowerCase().includes('volunteer')) :
    lower.includes('demand') || lower.includes('attendance') || lower.includes('orders') ? [scenario.nodes[0]] :
    [scenario.nodes[0]]
  );

  // Extract percentage shifts (e.g. "falls by 40%", "increases by 20%", "30% drop")
  const percentMatches = [...lower.matchAll(/(\d+(?:\.\d+)?)\s*%/g)];

  // Detect variable intent
  const isAvailability = lower.includes('availab') || lower.includes('offline') || lower.includes('shortage') || lower.includes('disrupt');
  const isDemand = lower.includes('demand') || lower.includes('attend') || lower.includes('order') || lower.includes('surge');
  const isCapacity = lower.includes('capacit') || lower.includes('buffer') || lower.includes('expand');
  const isCost = lower.includes('cost') || lower.includes('price') || lower.includes('wage');
  const isDelay = lower.includes('delay') || lower.includes('lag') || lower.includes('late');

  const variable = isAvailability ? 'availability' :
                   isCost ? 'unitCost' :
                   isDelay ? 'baseDelayHours' :
                   isCapacity ? 'capacity' : 'demand';

  // Detect operation & value
  let operation: 'multiply' | 'set' | 'add' = 'set';
  let val = 1.0;

  if (percentMatches.length > 0) {
    const pct = parseFloat(percentMatches[0][1]);
    const isReduction = lower.includes('fall') || lower.includes('drop') || lower.includes('reduc') || lower.includes('down') || lower.includes('decrease');
    operation = 'multiply';
    val = isReduction ? Math.max(0, (100 - pct) / 100) : (100 + pct) / 100;
  } else {
    // Check absolute number
    const numMatch = lower.match(/(?:to|by|=|set)\s*(\d+(?:\.\d+)?)/);
    if (numMatch) {
      val = parseFloat(numMatch[1]);
      operation = 'set';
    } else {
      unresolved.push('No explicit numerical quantity or percentage detected in input.');
      val = variable === 'availability' ? 0.6 : 1.25;
      operation = 'multiply';
    }
  }

  targetNodes.forEach(node => {
    proposedChanges.push({
      targetNodeId: node.id,
      targetNodeName: node.name,
      variable,
      operation,
      value: Number(val.toFixed(2)),
      reasoning: `Rule-based mapping from query: "${userInput}" matched ${node.name} for variable '${variable}' with ${operation} ${val}.`
    });
  });

  return {
    interpretation: `Identified intent to adjust ${variable} across ${targetNodes.map(n => n.name).join(', ')}.`,
    proposedChanges,
    confidenceScore: matchedNodes.length > 0 ? 0.92 : 0.75,
    unresolvedInformation: unresolved
  };
}

// ----------------------------------------------------
// 5. Feature B: Recovery Strategy Generator
// ----------------------------------------------------

export async function generateRecoveryStrategies(
  scenario: Scenario,
  result: SimulationResult
): Promise<{ proposal: AIRecoveryProposal; mode: 'GENERATIVE_AI' | 'RULE_BASED' }> {
  if (mlcEngine) {
    try {
      const prompt = buildRecoveryStrategyPrompt(scenario, result);
      const completion = await mlcEngine.chat.completions.create({
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.2,
        max_tokens: 800
      });

      const raw = completion.choices[0]?.message?.content || '';
      const parsed = cleanAndParseJSON(raw, AIRecoveryProposalSchema);
      if (parsed.success) {
        return { proposal: parsed.data, mode: 'GENERATIVE_AI' };
      }
      console.warn('Recovery AI output failed schema validation:', parsed.error);
    } catch (err) {
      console.warn('Inference error in recovery strategy generator:', err);
    }
  }

  // Deterministic Expert Engine Fallback
  return {
    proposal: generateRuleBasedRecoveryProposal(scenario, result),
    mode: 'RULE_BASED'
  };
}

export function generateRuleBasedRecoveryProposal(scenario: Scenario, result: SimulationResult): AIRecoveryProposal {
  const topBottleneck = result.rankedBottlenecks[0];
  const targetNode = topBottleneck ? scenario.nodes.find(n => n.id === topBottleneck.nodeId) : scenario.nodes[0];
  const targetName = targetNode?.name || 'Primary Stage';

  const strategies: any[] = [];

  if (topBottleneck && targetNode) {
    const requiredBuffer = Math.max(20, Math.round(topBottleneck.unmetDemand * 1.25));
    strategies.push({
      title: `Emergency Capacity Provisioning on ${targetName}`,
      actionType: 'capacity_buffer',
      targetComponent: targetName,
      proposedAction: `Provision +${requiredBuffer} ${targetNode.quantityUnit || 'units'} of temporary capacity to clear the active unmet demand of ${topBottleneck.unmetDemand.toFixed(1)}.`,
      expectedBenefits: `Eliminates throughput starvation for ${topBottleneck.downstreamImpactCount} downstream dependent components.`,
      operationalTradeoffs: `Increases operating expenditure by estimated ${formatCurrency((targetNode.unitCost || 10) * requiredBuffer, scenario.currency)}.`,
      associatedChanges: [
        {
          nodeId: targetNode.id,
          variable: 'capacity',
          operation: 'add',
          value: requiredBuffer
        }
      ]
    });

    strategies.push({
      title: `Tactical Demand Throttling on ${targetName}`,
      actionType: 'demand_throttling',
      targetComponent: targetName,
      proposedAction: 'Throttle incoming intake rate by 20% to stabilize utilization within safe operating limits.',
      expectedBenefits: 'Prevents cascade failure and stabilizes critical path delay without deploying capital.',
      operationalTradeoffs: 'Rejects or defers excess customer requests, impacting gross fulfillment volume.',
      associatedChanges: [
        {
          nodeId: targetNode.id,
          variable: 'demand',
          operation: 'multiply',
          value: 0.8
        }
      ]
    });
  } else {
    strategies.push({
      title: 'Operational Baseline Fine-Tuning',
      actionType: 'cost_containment',
      targetComponent: targetName,
      proposedAction: 'System is currently stable. Maintain baseline buffer allocations and review procurement contracts.',
      expectedBenefits: 'Maintains optimal 100/100 health score with zero unmet demand.',
      operationalTradeoffs: 'Carries standard operating fixed overhead.',
      associatedChanges: []
    });
  }

  return {
    analysisSummary: topBottleneck 
      ? `System health degraded to ${result.overallHealth}/100 driven by a severe bottleneck on ${targetName} (${topBottleneck.unmetDemand.toFixed(1)} unmet demand, ${topBottleneck.utilization.toFixed(0)}% utilization).`
      : `Operational system is balanced at ${result.overallHealth}/100 health with zero capacity deficits.`,
    identifiedRootBottleneck: topBottleneck ? topBottleneck.name : 'None',
    strategies,
    unmodelledConsiderations: [
      'Supplier contract notice lead-times',
      'Overtime labor union rate differentials',
      'Inventory holding space physical limits'
    ]
  };
}

// ----------------------------------------------------
// 6. Feature C: Decision Explanation Generator
// ----------------------------------------------------

export async function generateDecisionExplanation(
  scenario: Scenario,
  result: SimulationResult
): Promise<{ explanation: AIDecisionExplanation; mode: 'GENERATIVE_AI' | 'RULE_BASED' }> {
  if (mlcEngine) {
    try {
      const prompt = buildDecisionExplanationPrompt(scenario, result);
      const completion = await mlcEngine.chat.completions.create({
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.2,
        max_tokens: 700
      });

      const raw = completion.choices[0]?.message?.content || '';
      const parsed = cleanAndParseJSON(raw, AIDecisionExplanationSchema);
      if (parsed.success) {
        return { explanation: parsed.data, mode: 'GENERATIVE_AI' };
      }
      console.warn('Explanation AI output failed schema validation:', parsed.error);
    } catch (err) {
      console.warn('Inference error in decision explanation generator:', err);
    }
  }

  // Deterministic Expert Engine Fallback
  return {
    explanation: generateRuleBasedDecisionExplanation(scenario, result),
    mode: 'RULE_BASED'
  };
}

export function generateRuleBasedDecisionExplanation(scenario: Scenario, result: SimulationResult): AIDecisionExplanation {
  const isBottlenecked = result.rankedBottlenecks.length > 0;
  const top = result.rankedBottlenecks[0];

  return {
    headline: isBottlenecked
      ? `Bottleneck Alert: ${top.name} Operating at ${top.utilization.toFixed(0)}% Capacity with ${top.unmetDemand.toFixed(1)} Unmet Units`
      : `Nominal Operations: Scenario Running at Optimal ${result.overallHealth}/100 Health Score`,
    executiveSummary: isBottlenecked
      ? `The configured scenario causes severe capacity constriction at ${top.name}, propagating supply deficits across ${top.downstreamImpactCount} downstream components. Total unmet demand stands at ${result.totalUnmet.toFixed(1)} units with estimated operating cost of ${formatCurrency(result.totalCost, result.currency)}.`
      : `All ${scenario.nodes.length} components are operating within safe bounds. Total demand of ${result.totalDemand} units is 100% fulfilled with a budget variance of ${formatCurrency(result.budgetVariance, result.currency)}.`,
    criticalPathAnalysis: isBottlenecked
      ? `Upstream shortages on ${top.name} restrict throughput via strict prerequisite relationships. Leontief aggregation limits downstream capacity to ${result.nodes.find(n => n.nodeId === top.nodeId)?.effectiveCapacity} units.`
      : 'All critical path dependencies are satisfied with zero bottleneck aggregation restrictions.',
    financialAndCostImpact: `Total estimated operating cost is ${formatCurrency(result.totalCost, result.currency)} against a budget of ${formatCurrency(result.budget, result.currency)} (variance: ${formatCurrency(result.budgetVariance, result.currency)}).`,
    keyRisks: isBottlenecked ? [
      `Throughput starvation on ${top.name} cascading to downstream nodes`,
      `Budget variance of ${formatCurrency(result.budgetVariance, result.currency)} if overtime buffer is required`,
      'Customer order SLA breach due to accumulated propagation lag'
    ] : [
      'Potential vulnerability to unmodelled external supply disruptions',
      'Fixed cost overhead under sub-nominal demand conditions'
    ],
    recommendedNextSteps: isBottlenecked ? [
      `Review capacity expansion options for ${top.name}`,
      'Evaluate tactical demand throttling or secondary supplier activation',
      'Execute stress-testing under pessimistic uncertainty bands'
    ] : [
      'Conduct pessimistic stress testing to verify operational safety margins',
      'Archive current baseline run for variance benchmarking'
    ]
  };
}

// ----------------------------------------------------
// 7. Feature D: Prompt Battle Arena
// ----------------------------------------------------

export async function executePromptBattle(
  scenario: Scenario,
  result: SimulationResult
): Promise<PromptBattleResult> {
  const contextSummary = JSON.stringify({
    scenario: scenario.name,
    health: result.overallHealth,
    unmetDemand: result.totalUnmet,
    cost: result.totalCost,
    bottlenecks: result.bottlenecks
  });

  const promptStyles: Array<{ style: 'zero_shot' | 'role_based' | 'structured_context'; name: string; prompt: string }> = [
    {
      style: 'zero_shot',
      name: 'Zero-Shot Quick Query',
      prompt: `Analyze the operational scenario "${scenario.name}". Unmet demand is ${result.totalUnmet}, cost is ${result.totalCost}. What should we do?`
    },
    {
      style: 'role_based',
      name: 'Role-Constrained Risk Architect',
      prompt: `You are the Lead Risk Architect for WHATIF AI.
Scenario Context: ${contextSummary}.
STRICT RULE: Do not invent numbers. Rely strictly on the telemetry provided.
Identify the root bottleneck and propose two tactical interventions with concrete trade-offs.`
    },
    {
      style: 'structured_context',
      name: 'Context-Aware Structured Blueprint',
      prompt: `<|im_start|>system
Return strictly structured diagnostic JSON with schema { "rootBottleneck": string, "rationale": string, "actions": string[] }.
Telemetry: ${contextSummary}
<|im_end|>
<|im_start|>user
Diagnose bottlenecks and interventions.
<|im_end|>`
    }
  ];

  const rounds: PromptBattleRound[] = [];

  for (const styleObj of promptStyles) {
    const start = performance.now();
    let responseText = '';

    if (mlcEngine) {
      try {
        const comp = await mlcEngine.chat.completions.create({
          messages: [{ role: 'user', content: styleObj.prompt }],
          temperature: 0.2,
          max_tokens: 350
        });
        responseText = comp.choices[0]?.message?.content || '';
      } catch (err: any) {
        responseText = `Model generation error: ${err.message}. Using expert rule response.`;
      }
    }

    if (!responseText || responseText.startsWith('Model generation error')) {
      // Deterministic synthetic response matching prompt style
      if (styleObj.style === 'zero_shot') {
        responseText = `Based on scenario ${scenario.name}, unmet demand is ${result.totalUnmet}. Expand capacity or throttle demand to prevent further losses.`;
      } else if (styleObj.style === 'role_based') {
        responseText = `ROLE BRIEFING: As Lead Risk Architect, the primary bottleneck is ${result.bottlenecks[0] || 'None'}. Unmet demand of ${result.totalUnmet} units threatens downstream operations. Intervention 1: Buffer capacity (+25%). Tradeoff: Increases operating expenditure by ${formatCurrency(result.totalCost * 0.15, result.currency)}. Intervention 2: Demand throttle (-15%). Tradeoff: Foregoes marginal revenue.`;
      } else {
        responseText = JSON.stringify({
          rootBottleneck: result.bottlenecks[0] || 'None',
          rationale: `System health at ${result.overallHealth}/100 with ${result.totalUnmet} unmet units.`,
          actions: ['Add buffer capacity to critical stage', 'Activate secondary supply route']
        }, null, 2);
      }
    }

    const duration = Math.round(performance.now() - start);

    // Deterministic Evaluation Rubric
    const scores = evaluatePromptResponse(responseText, scenario, result, styleObj.style);

    rounds.push({
      style: styleObj.style,
      name: styleObj.name,
      promptSent: styleObj.prompt,
      response: responseText,
      executionTimeMs: Math.max(12, duration),
      scores,
      metricCitations: extractMetricCitations(responseText, result),
      hallucinatedClaims: detectHallucinatedClaims(responseText, result)
    });
  }

  // Determine winner by highest composite score
  const sorted = [...rounds].sort((a, b) => b.scores.compositeScore - a.scores.compositeScore);
  const winner = sorted[0];

  return {
    scenarioName: scenario.name,
    rounds,
    winnerStyle: winner.style,
    rubricSummary: `"${winner.name}" achieved highest composite score (${winner.scores.compositeScore}/100) through superior constraint adherence and zero hallucinated claims.`,
    mode: mlcEngine ? 'GENERATIVE_AI' : 'RULE_BASED'
  };
}

function evaluatePromptResponse(
  text: string,
  scenario: Scenario,
  result: SimulationResult,
  style: 'zero_shot' | 'role_based' | 'structured_context'
): PromptBattleRound['scores'] {
  const lower = text.toLowerCase();

  // 1. Hallucination Index (100 = flawless, docks points for fabricated percentages/numbers)
  let hallucinationIndex = 100;
  const numbers = text.match(/\b\d+(?:\.\d+)?\b/g)?.map(Number) || [];
  const knownNumbers = new Set<number>([
    result.overallHealth,
    Math.round(result.totalUnmet),
    Math.round(result.totalDemand),
    Math.round(result.totalCost),
    Math.round(result.budget),
    Math.round(result.budgetVariance),
    15, 20, 25, 50, 100 // standard allowable percentages
  ]);

  const fabricated = numbers.filter(n => n > 10 && !knownNumbers.has(Math.round(n)));
  hallucinationIndex = Math.max(40, 100 - (fabricated.length * 15));

  // 2. Component Coverage
  const mentionedComponents = scenario.nodes.filter(n => 
    lower.includes(n.name.toLowerCase()) || lower.includes(n.id.toLowerCase())
  );
  const componentCoverage = Math.min(100, Math.round((mentionedComponents.length / Math.max(1, scenario.nodes.length)) * 140));

  // 3. Constraint Adherence
  let constraintAdherence = 85;
  if (style === 'structured_context') {
    constraintAdherence = text.includes('{') && text.includes('}') ? 100 : 60;
  } else if (style === 'role_based') {
    constraintAdherence = lower.includes('tradeoff') || lower.includes('trade-off') ? 95 : 75;
  } else {
    constraintAdherence = 70; // zero shot lacks constraints
  }

  // 4. Actionability
  const actionTerms = ['provision', 'buffer', 'expand', 'throttle', 'secondary', 'supplier', 'capacity', 'intervention', 'actions'];
  const matchedActions = actionTerms.filter(t => lower.includes(t));
  const actionability = Math.min(100, matchedActions.length * 20);

  // Weighted Composite: 35% Hallucination, 25% Actionability, 20% Constraints, 20% Component Coverage
  const compositeScore = Math.round(
    (hallucinationIndex * 0.35) +
    (actionability * 0.25) +
    (constraintAdherence * 0.20) +
    (componentCoverage * 0.20)
  );

  return {
    hallucinationIndex,
    componentCoverage,
    constraintAdherence,
    actionability,
    compositeScore
  };
}

function extractMetricCitations(text: string, result: SimulationResult): string[] {
  const citations: string[] = [];
  if (text.includes(String(result.overallHealth))) citations.push(`Health Score: ${result.overallHealth}`);
  if (text.includes(String(result.totalUnmet))) citations.push(`Unmet Demand: ${result.totalUnmet}`);
  if (text.includes(String(result.totalCost))) citations.push(`Operating Cost: ${result.totalCost}`);
  if (result.bottlenecks.some(b => text.toLowerCase().includes(b.toLowerCase()))) {
    citations.push(`Bottleneck: ${result.bottlenecks[0]}`);
  }
  return citations;
}

function detectHallucinatedClaims(text: string, result: SimulationResult): string[] {
  const flags: string[] = [];
  const numbers = text.match(/\b\d+(?:\.\d+)?\b/g)?.map(Number) || [];
  const legitimate = new Set([result.overallHealth, result.totalUnmet, result.totalDemand, result.totalCost, result.budget, 1, 2, 3, 10, 15, 20, 25, 50, 80, 100]);
  const unknown = numbers.filter(n => n > 25 && !legitimate.has(Math.round(n)));
  if (unknown.length > 0) {
    flags.push(`Unverifiable numeric figure(s) detected: ${unknown.slice(0, 3).join(', ')}`);
  }
  return flags;
}
