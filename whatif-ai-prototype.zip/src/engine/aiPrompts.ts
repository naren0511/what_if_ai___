import type { Scenario, ScenarioChange, SimulationResult } from '../types/index.ts';

export function buildNLScenarioPrompt(userInput: string, scenario: Scenario): string {
  const componentList = scenario.nodes.map(n => 
    `- ID: "${n.id}", Name: "${n.name}", Type: "${n.type}", Capacity: ${n.capacity}, Demand: ${n.demand}, Availability: ${n.availability}, UnitCost: ${n.unitCost}`
  ).join('\n');

  return `<|im_start|>system
You are the Natural Language Scenario Interpreter for WHATIF AI.
Your task is to parse a user's what-if hypothesis into explicit, structured scenario changes.

AVAILABLE COMPONENTS:
${componentList}

SUPPORTED VARIABLES:
- "demand": customer/intake volume
- "capacity": maximum throughput limit
- "availability": operating factor (0.0 to 1.0)
- "unitCost": cost per unit
- "baseDelayHours": baseline operational lag in hours
- "fixedCost": invariant overhead cost

SUPPORTED OPERATIONS:
- "set": absolute replacement value
- "add": positive or negative delta (e.g. +20, -50)
- "multiply": proportional scaling factor (e.g. 1.2 for +20%, 0.6 for -40%)

STRICT JSON OUTPUT FORMAT (Respond ONLY with valid JSON):
{
  "interpretation": "Clear natural language summary of the hypothesis",
  "proposedChanges": [
    {
      "targetNodeId": "exact_node_id_from_list",
      "targetNodeName": "exact_node_name",
      "variable": "availability",
      "operation": "multiply",
      "value": 0.6,
      "reasoning": "40% drop corresponds to 0.6 multiplier"
    }
  ],
  "confidenceScore": 0.95,
  "unresolvedInformation": []
}
<|im_end|>
<|im_start|>user
Hypothesis: "${userInput}"
<|im_end|>
<|im_start|>assistant
`;
}

export function buildRecoveryStrategyPrompt(scenario: Scenario, result: SimulationResult): string {
  const bottlenecks = result.rankedBottlenecks.map(b => 
    `- Bottleneck Component: ${b.name} (ID: ${b.nodeId}), Unmet Demand: ${b.unmetDemand.toFixed(1)}, Utilization: ${b.utilization.toFixed(0)}%, Downstream Cascades: ${b.downstreamImpactCount}`
  ).join('\n') || 'None detected.';

  const components = scenario.nodes.map(n => 
    `- ${n.name} (ID: ${n.id}): Type=${n.type}, Capacity=${n.capacity}, CostBasis=${n.costBasis}, UnitCost=${n.unitCost}`
  ).join('\n');

  return `<|im_start|>system
You are the Operational Recovery Advisor for WHATIF AI.
Propose structured recovery interventions for bottlenecks detected by the deterministic simulation.
DO NOT recalculate metrics. Rely entirely on the factual outcomes provided.

FACTUAL SIMULATION OUTCOMES:
- Overall Health Score: ${result.overallHealth}/100
- Total Unmet Demand: ${result.totalUnmet.toFixed(1)} units
- Total Operating Cost: ${result.totalCost} ${result.currency} (Budget: ${result.budget} ${result.currency}, Variance: ${result.budgetVariance})
- Critical Bottlenecks:
${bottlenecks}

AVAILABLE COMPONENTS:
${components}

STRICT JSON OUTPUT FORMAT (Respond ONLY with valid JSON):
{
  "analysisSummary": "Executive diagnostic of the operational failure cascade",
  "identifiedRootBottleneck": "${result.rankedBottlenecks[0]?.name || 'None'}",
  "strategies": [
    {
      "title": "Strategy Name",
      "actionType": "capacity_buffer",
      "targetComponent": "Component Name",
      "proposedAction": "Actionable description of the tactical intervention",
      "expectedBenefits": "Concrete operational payoff",
      "operationalTradeoffs": "Downstream costs or friction",
      "associatedChanges": [
        {
          "nodeId": "exact_node_id",
          "variable": "capacity",
          "operation": "add",
          "value": 50
        }
      ]
    }
  ],
  "unmodelledConsiderations": ["Lead time to provision resources", "Overtime wage escalation"]
}
<|im_end|>
<|im_start|>user
Propose recovery interventions for this simulation run.
<|im_end|>
<|im_start|>assistant
`;
}

export function buildDecisionExplanationPrompt(scenario: Scenario, result: SimulationResult): string {
  const traces = result.nodes.filter(n => n.affected).slice(0, 5).map(n => 
    `- ${n.name}: Capacity ${n.effectiveCapacity}, Demand ${n.demand}, Unmet ${n.unmetDemand}, Delay ${n.delayHours}h. Trace: ${n.trace.join(' | ')}`
  ).join('\n');

  return `<|im_start|>system
You are the Chief Operational Risk Briefing Assistant for WHATIF AI.
Synthesize the deterministic simulation traces into an evidence-based executive brief.
RULE: Every numeric claim MUST match the provided simulation telemetry. Do not invent numbers.

TELEMETRY:
- Scenario: ${scenario.name} (${scenario.domain})
- Health: ${result.overallHealth}/100
- Total Demand: ${result.totalDemand} | Fulfilled: ${result.totalFulfilled} | Unmet: ${result.totalUnmet}
- Cost: ${result.totalCost} ${result.currency} | Budget Variance: ${result.budgetVariance}
- Top Bottlenecks: ${result.bottlenecks.join(', ') || 'None'}
- Propagation Traces:
${traces}

STRICT JSON OUTPUT FORMAT:
{
  "headline": "One-line punchy executive assessment",
  "executiveSummary": "2-3 sentences summarizing the situation and root cause",
  "criticalPathAnalysis": "Detailed chain of propagation citing exact delay hours and capacity limits",
  "financialAndCostImpact": "Detailed budget impact analysis referencing total cost and variance",
  "keyRisks": ["Risk 1 citing specific component", "Risk 2 citing specific bottleneck"],
  "recommendedNextSteps": ["Step 1", "Step 2"]
}
<|im_end|>
<|im_start|>user
Generate the decision briefing for this simulation.
<|im_end|>
<|im_start|>assistant
`;
}
