#!/usr/bin/env bash
cd "$(dirname "$0")"
python3 -m http.server 4173 --directory standalone
